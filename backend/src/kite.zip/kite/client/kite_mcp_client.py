# # src/kite/client/kite_mcp_client.py

# import asyncio
# import contextlib
# import re
# import webbrowser
# from typing import Any, Dict, Optional

# from fastmcp import Client
# from fastmcp.client.transports import SSETransport
# from fastmcp.exceptions import ToolError


# # Flexible URL patterns (same as working version)
# KITE_URL_REGEX = re.compile(r"https?://[^\s)]+kite\.[^\s)]+", re.IGNORECASE)
# GENERIC_URL_REGEX = re.compile(r"https?://[^\s)]+", re.IGNORECASE)


# class KiteMCPClient:
#     """Stable SSE-based Zerodha Kite MCP client (fully fixed version)."""

#     def __init__(self,
#                  url: str = "https://mcp.kite.trade/sse",
#                  headers: Optional[Dict[str, str]] = None):

#         self.transport = SSETransport(url=url, headers=headers or {})
#         self._client: Optional[Client] = None

#     # --------------------------
#     # Context Manager lifecycle
#     # --------------------------
#     async def __aenter__(self):
#         await self.connect()
#         return self

#     async def __aexit__(self, exc_type, exc, tb):
#         await self.close(exc_type, exc, tb)

#     # --------------------------
#     # Connect / Close
#     # --------------------------
#     async def connect(self):
#         if self._client is None:
#             self._client = Client(self.transport)
#             await self._client.__aenter__()

#     async def close(self, exc_type=None, exc=None, tb=None):
#         """Close SSE reader and client cleanly (same as working version)."""
#         if self._client:
#             reader = getattr(self.transport, "reader_task", None)
#             if reader and not reader.done():
#                 reader.cancel()
#                 with contextlib.suppress(Exception):
#                     await reader

#             with contextlib.suppress(Exception):
#                 await self._client.__aexit__(exc_type, exc, tb)

#         self._client = None

#     # --------------------------
#     # Tool call
#     # --------------------------
#     async def call(self, tool_name: str, args: Optional[Dict[str, Any]] = None):
#         if not self._client:
#             await self.connect()

#         try:
#             return await self._client.call_tool(tool_name, args or {})
#         except ToolError as e:
#             print(f"❌ Tool error: {e}")
#             raise

#     # --------------------------
#     # Collect text chunks (needed for URL parsing)
#     # --------------------------
#     @staticmethod
#     def _collect_text_chunks(result: Any) -> str:
#         texts = []
#         contents = getattr(result, "content", None)
#         if isinstance(contents, list):
#             for item in contents:
#                 if getattr(item, "type", "") == "text":
#                     t = getattr(item, "text", "")
#                     if t:
#                         texts.append(t)
#         return "\n".join(texts).strip()

#     # --------------------------
#     # Flexible login URL extraction (same logic as working version)
#     # --------------------------
#     @staticmethod
#     def extract_login_url(login_result: Any) -> Optional[str]:

#         # (1) From text content
#         raw_text = KiteMCPClient._collect_text_chunks(login_result)
#         if raw_text:
#             m = KITE_URL_REGEX.search(raw_text)
#             if m:
#                 return m.group(0)

#             m2 = GENERIC_URL_REGEX.search(raw_text)
#             if m2:
#                 return m2.group(0)

#         # (2) Try JSON payloads (structured_content, data)
#         for attr in ("structured_content", "data"):
#             payload = getattr(login_result, attr, None)
#             if not payload:
#                 continue

#             if isinstance(payload, dict):
#                 for key in ("login_url", "url", "href"):
#                     v = payload.get(key)
#                     if isinstance(v, str) and v.startswith("http"):
#                         return v

#                 for v in payload.values():
#                     if isinstance(v, str):
#                         m = KITE_URL_REGEX.search(v) or GENERIC_URL_REGEX.search(v)
#                         if m:
#                             return m.group(0)

#             if isinstance(payload, list):
#                 for item in payload:
#                     if isinstance(item, str):
#                         m = KITE_URL_REGEX.search(item) or GENERIC_URL_REGEX.search(item)
#                         if m:
#                             return m.group(0)
#                     if isinstance(item, dict):
#                         for v in item.values():
#                             if isinstance(v, str):
#                                 m = KITE_URL_REGEX.search(v) or GENERIC_URL_REGEX.search(v)
#                                 if m:
#                                     return m.group(0)

#         return None

#     # --------------------------
#     # Login helper
#     # --------------------------
#     async def run_login_flow(self) -> str:
#         login_res = await self.call("login", {})
#         login_url = self.extract_login_url(login_res)

#         if not login_url:
#             raw = self._collect_text_chunks(login_res)
#             print("⚠️ Could not extract login URL.")
#             if raw:
#                 print("MCP login output:")
#                 print(raw)
#             raise RuntimeError("Could not extract login URL from MCP login tool.")

#         print(f"\n🔗 OPEN THIS LOGIN URL:\n{login_url}\n")
#         try:
#             webbrowser.open(login_url)
#         except Exception:
#             print("⚠️ Could not open browser automatically.")

#         input("⏳ Login in browser → then press ENTER here... ")

#         return login_url







# src/kite/client/kite_mcp_client.py
import asyncio
import contextlib
import re
import webbrowser
from typing import Any, Dict, Optional

from fastmcp import Client
from fastmcp.client.transports import SSETransport
from fastmcp.exceptions import ToolError

# URL regex patterns
KITE_URL_REGEX = re.compile(r"https?://[^\s)]+kite\.[^\s)]+", re.IGNORECASE)
GENERIC_URL_REGEX = re.compile(r"https?://[^\s)]+", re.IGNORECASE)


class KiteMCPClient:
    """Compatible Zerodha Kite MCP client for your fastmcp version."""

    def __init__(self, url: str = "https://mcp.kite.trade/sse",
                 headers: Optional[Dict[str, str]] = None):

        # In your fastmcp version:
        # ✔ URL must be passed into SSETransport
        # ✔ SSETransport is the ONLY working transport
        self.transport = SSETransport(url=url, headers=headers or {})
        self._client: Optional[Client] = None

    # --------------------------
    # Context Manager
    # --------------------------
    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close(exc_type, exc, tb)

    # --------------------------
    # Connect
    # --------------------------
    async def connect(self):
        if self._client is None:
            # Your Client() accepts ONLY: Client(transport)
            self._client = Client(self.transport)
            await self._client.__aenter__()

    # --------------------------
    # Close
    # --------------------------
    async def close(self, exc_type=None, exc=None, tb=None):
        if self._client:
            # backward-compatible cleanup
            with contextlib.suppress(Exception):
                await self._client.__aexit__(exc_type, exc, tb)

        self._client = None

    # --------------------------
    # Tool call
    # --------------------------
    async def call(self, tool_name: str, args: Optional[Dict[str, Any]] = None):
        if not self._client:
            await self.connect()

        try:
            return await self._client.call_tool(tool_name, args or {})
        except ToolError as e:
            print(f"❌ Tool error: {e}")
            raise

    # --------------------------
    # Extract text
    # --------------------------
    @staticmethod
    def _collect_text_chunks(result: Any) -> str:
        texts = []
        contents = getattr(result, "content", None)
        if isinstance(contents, list):
            for item in contents:
                if getattr(item, "type", "") == "text":
                    t = getattr(item, "text", "")
                    if t:
                        texts.append(t)
        return "\n".join(texts).strip()

    # --------------------------
    # LOGIN URL extraction
    # --------------------------
    @staticmethod
    def extract_login_url(login_result: Any) -> Optional[str]:
        raw_text = KiteMCPClient._collect_text_chunks(login_result)
        if raw_text:
            m = KITE_URL_REGEX.search(raw_text)
            if m:
                return m.group(0)
            m2 = GENERIC_URL_REGEX.search(raw_text)
            if m2:
                return m2.group(0)

        for attr in ("structured_content", "data"):
            payload = getattr(login_result, attr, None)
            if not payload:
                continue

            if isinstance(payload, dict):
                for key in ("login_url", "url", "href"):
                    v = payload.get(key)
                    if isinstance(v, str) and v.startswith("http"):
                        return v

                for v in payload.values():
                    if isinstance(v, str):
                        m = KITE_URL_REGEX.search(v) or GENERIC_URL_REGEX.search(v)
                        if m:
                            return m.group(0)

        return None

    # --------------------------
    # Login helper
    # --------------------------
    async def run_login_flow(self) -> str:
        login_res = await self.call("login", {})
        login_url = self.extract_login_url(login_res)

        if not login_url:
            raw = self._collect_text_chunks(login_res)
            print("⚠️ Could not extract login URL.")
            if raw:
                print("MCP login output:")
                print(raw)
            raise RuntimeError("Could not extract login URL from MCP login tool.")

        print(f"\n🔗 OPEN THIS LOGIN URL:\n{login_url}\n")
        try:
            webbrowser.open(login_url)
        except Exception:
            print("⚠️ Could not open browser automatically.")

        input("⏳ Login in browser → then press ENTER here... ")
        return login_url
