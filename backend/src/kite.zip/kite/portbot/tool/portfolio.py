

# import sys
# from pathlib import Path
# sys.path.append(str(Path(__file__).parent.parent))

# import json
# from typing import Any, Dict, Optional, List

# from base import Agent
# from src.kite.client.kite_mcp_client import KiteMCPClient


# def _unwrap_json(result: Any) -> Any:
#     texts: List[str] = []
#     if hasattr(result, "content") and isinstance(result.content, list):
#         for it in result.content:
#             if getattr(it, "type", None) == "text":
#                 t = getattr(it, "text", "")
#                 if t:
#                     texts.append(t)
#     raw = "\n".join(texts).strip()
#     if raw:
#         try:
#             return json.loads(raw)
#         except Exception:
#             pass
#     if "```" in raw:
#         for chunk in raw.split("```"):
#             s = chunk.strip()
#             try:
#                 return json.loads(s)
#             except Exception:
#                 continue
#     for attr in ("structured_content", "data"):
#         if hasattr(result, attr):
#             val = getattr(result, attr)
#             if val is not None:
#                 return val
#     return raw if raw else None


# class PortfolioAgent(Agent):
#     name = "portfolio"
#     description = "Manages portfolio data including holdings, positions, and mutual funds"

#     tools = [
#         {"name": "get_holdings", "description": "Retrieve all stock holdings in the portfolio with quantities and P&L", "parameters": {}},
#         {"name": "get_positions", "description": "Get current open positions for the day with entry and exit details", "parameters": {}},
#         {"name": "get_mf_holdings", "description": "Fetch mutual fund holdings with current value and returns", "parameters": {}},
#     ]

#     def __init__(self, kite_client: KiteMCPClient, shared_state: Optional[Dict[str, Any]] = None):
#         super().__init__(shared_state)
#         self.kite_client = kite_client

#     async def run(self, tool_name: str, **kwargs: Any) -> Dict[str, Any]:
#         if tool_name == "get_holdings":
#             return await self._get_holdings()
#         elif tool_name == "get_positions":
#             return await self._get_positions()
#         elif tool_name == "get_mf_holdings":
#             return await self._get_mf_holdings()
#         raise ValueError(f"Unknown tool: {tool_name}")

#     async def _get_holdings(self) -> Dict[str, Any]:
#         obj = _unwrap_json(await self.kite_client.call("get_holdings", {}))
#         rows = obj if isinstance(obj, list) else []
#         compact = []
#         total_mv = 0.0
#         total_pnl = 0.0

#         for r in rows:
#             sym = r.get("tradingsymbol")
#             qty = r.get("quantity", 0)
#             avg = r.get("average_price", 0.0)
#             ltp = r.get("last_price", 0.0)
#             pnl = r.get("pnl", (ltp - avg) * qty if isinstance(qty, (int, float)) else 0.0)
#             mv  = ltp * qty if isinstance(qty, (int, float)) else 0.0
#             total_mv += float(mv)
#             total_pnl += float(pnl)
#             compact.append({
#                 "symbol": sym,
#                 "qty": qty,
#                 "avg": avg,
#                 "ltp": ltp,
#                 "pnl": pnl,
#             })

#         if compact:
#             header = f"📦 Equity Holdings — {len(compact)} item(s) | Approx MV: ₹{total_mv:.2f} | P&L: ₹{total_pnl:.2f}"
#             lines = ["Symbol     Qty   Avg      LTP      P&L"]
#             for c in compact:
#                 lines.append(f"{c['symbol']:<10} {c['qty']:<5} {c['avg']:<8.2f} {c['ltp']:<8.2f} {c['pnl']:.2f}")
#             text = header + "\n" + "\n".join(lines)
#         else:
#             text = "📦 Equity Holdings — None"

#         return {"status": "success", "message": text, "data": compact}

#     async def _get_positions(self) -> Dict[str, Any]:
#         obj = _unwrap_json(await self.kite_client.call("get_positions", {}))
#         rows = obj if isinstance(obj, list) else []
#         day_pnl = 0.0
#         for r in rows:
#             day_pnl += float(r.get("pnl", 0.0))

#         if rows:
#             lines = ["Symbol     Qty    P&L"]
#             for r in rows:
#                 lines.append(f"{r.get('tradingsymbol',''):<10} {r.get('quantity',0):<6} {float(r.get('pnl',0.0)):.2f}")
#             text = f"📊 Open Positions — {len(rows)} | Day P&L: ₹{day_pnl:.2f}\n" + "\n".join(lines)
#         else:
#             text = f"📊 Open Positions — None | Day P&L: ₹{day_pnl:.2f}\nNone"

#         compact = [
#             {"symbol": r.get("tradingsymbol"), "qty": r.get("quantity"), "pnl": r.get("pnl", 0.0)}
#             for r in rows
#         ]
#         return {"status": "success", "message": text, "data": compact}

#     async def _get_mf_holdings(self) -> Dict[str, Any]:
#         obj = _unwrap_json(await self.kite_client.call("get_mf_holdings", {}))
#         rows = obj if isinstance(obj, list) else []

#         compact = []
#         invested = 0.0
#         value = 0.0

#         for r in rows:
#             scheme = r.get("fund", "")
#             units = float(r.get("quantity", 0.0))
#             avg   = float(r.get("average_price", 0.0))
#             nav   = float(r.get("last_price", 0.0))
#             cur_val = units * nav
#             inv_val = units * avg
#             invested += inv_val
#             value += cur_val
#             gain_pct = ((cur_val - inv_val) / inv_val * 100.0) if inv_val > 0 else 0.0
#             compact.append({
#                 "scheme": scheme,
#                 "units": units,
#                 "avg_nav": avg,
#                 "nav": nav,
#                 "value": cur_val,
#                 "gain_pct": gain_pct,
#             })

#         if compact:
#             header = f"🏦 Mutual Funds — {len(compact)} scheme(s) | Est. value: ₹{value:.2f} | Invested: ₹{invested:.2f} | Gain: {((value - invested)/invested*100.0 if invested>0 else 0.0):.2f}%"
#             lines = ["Scheme                             Units    Avg      NAV     Value"]
#             for c in compact:
#                 nm = (c['scheme'][:30] + "…") if len(c['scheme']) > 31 else c['scheme']
#                 lines.append(f"{nm:<33} {c['units']:<7.2f} {c['avg_nav']:<8.2f} {c['nav']:<7.2f} {c['value']:.2f}")
#             text = header + "\n" + "\n".join(lines)
#         else:
#             text = "🏦 Mutual Funds — None"

#         return {"status": "success", "message": text, "data": compact}



# # # C:\Users\Ganesh.More\Desktop\GaneshMore\KiteInfi\src\kite\portbot\tool\portfolio.py
# import sys
# from pathlib import Path
# sys.path.append(str(Path(__file__).parent.parent))

# import os
# from typing import Any, Dict, Optional, List, Tuple
# from dotenv import load_dotenv

# load_dotenv(override=True)

# from src.kite.portbot.base import Agent
# from src.kite.client.kite_mcp_client import KiteMCPClient

# # ✅ Shared Unwrappers
# from src.kite.portbot.utils.unwrapper import unwrap_json, unwrap_list

# # -------------------------
# # Dummy Payloads (safe)
# # -------------------------
# DUMMY_HOLDINGS = [
#     {"tradingsymbol": "INFY", "quantity": 2, "average_price": 1450.0, "last_price": 1472.4},
#     {"tradingsymbol": "RELIANCE", "quantity": 1, "average_price": 1400.0, "last_price": 1465.2},
#     {"tradingsymbol": "HDFCBANK", "quantity": 3, "average_price": 1500.0, "last_price": 1528.5},
# ]

# DUMMY_POSITIONS = [
#     {"tradingsymbol": "TCS",  "quantity": 1,  "pnl": 120.50},
#     {"tradingsymbol": "SBIN", "quantity": -2, "pnl": -45.75},
# ]

# # -------------------------
# # Merge Helpers
# # -------------------------
# def _merge_unique_by_key(primary: List[Dict[str, Any]], secondary: List[Dict[str, Any]], key: str):
#     seen = {x.get(key) for x in primary if isinstance(x, dict)}
#     merged = list(primary)
#     for x in secondary:
#         if not isinstance(x, dict):
#             continue
#         k = x.get(key)
#         if k and k not in seen:
#             merged.append(x)
#             seen.add(k)
#     return merged


# # Add the _table function at the top
# def _table(headers, rows):
#     """
#     Simple table formatting function to create a string representation of tabular data.
#     """
#     table_str = ""
#     # Add headers
#     header_row = " | ".join([f"{h[0]:<{h[1]}}" for h in headers])
#     table_str += header_row + "\n"
#     table_str += "-" * len(header_row) + "\n"

#     # Add rows
#     for row in rows:
#         table_str += " | ".join([str(item).ljust(headers[i][1]) for i, item in enumerate(row)]) + "\n"
    
#     return table_str



# # -------------------------
# # Portfolio Agent
# # -------------------------
# class PortfolioAgent(Agent):
#     name = "portfolio"
#     description = "Manages portfolio data including holdings, positions, and mutual funds"

#     tools = [
#         {"name": "get_holdings", "description": "Retrieve all stock holdings in the portfolio with quantities and P&L", "parameters": {}},
#         {"name": "get_positions", "description": "Get current open positions for the day with entry and exit details", "parameters": {}},
#         {"name": "get_mf_holdings", "description": "Fetch mutual fund holdings with current value and returns", "parameters": {}},
#     ]

#     def __init__(self, kite_client: KiteMCPClient, shared_state: Optional[Dict[str, Any]] = None):
#         super().__init__(shared_state)
#         self.kite_client = kite_client
#         # Ensure we correctly interpret the environment variable
#         self.use_dummy = os.getenv("DUMMY_FOR_PORTFOLIO", "0").strip().lower() not in ("0", "false")
#         print(f"Use dummy data: {self.use_dummy}")  # Debug log

#     async def run(self, tool_name: str, **kwargs: Any) -> Dict[str, Any]:
#         print(f"Running tool: {tool_name}")
#         if tool_name == "get_holdings":
#             return await self._get_holdings()
#         elif tool_name == "get_positions":
#             return await self._get_positions()
#         elif tool_name == "get_mf_holdings":
#             return await self._get_mf_holdings()
#         raise ValueError(f"Unknown tool: {tool_name}")

#     # ============================
#     #          HOLDINGS
#     # ============================
#     async def _get_holdings(self):
#         # Fetch MCP data
#         res = await self.kite_client.call("get_holdings", {})
#         print(f"API response for holdings: {res}")  # Debug log
#         rows_real = unwrap_list(unwrap_json(res))

#         # Debug log for rows_real
#         print(f"Real data (MCP): {rows_real}")

#         # Merge with dummy data if applicable
#         if self.use_dummy:
#             rows_all = _merge_unique_by_key(rows_real, DUMMY_HOLDINGS, "tradingsymbol")
#         else:
#             rows_all = rows_real

#         # Debug log for rows_all
#         print(f"All merged data: {rows_all}")

#         compact = []
#         total_mv = 0.0
#         total_pnl = 0.0

#         for r in rows_all:
#             if not isinstance(r, dict):
#                 continue
#             sym = r.get("tradingsymbol", "")
#             qty = float(r.get("quantity", 0) or 0)
#             avg = float(r.get("average_price", 0.0) or 0.0)
#             ltp = float(r.get("last_price", 0.0) or 0.0)
#             pnl = float(r.get("pnl", (ltp - avg) * qty)) if qty != 0 else float(r.get("pnl", 0.0))

#             mv = qty * ltp
#             total_mv += mv
#             total_pnl += pnl

#             compact.append({
#                 "symbol": sym,
#                 "qty": qty,
#                 "avg": avg,
#                 "ltp": ltp,
#                 "pnl": pnl,
#             })

#         if compact:
#             header = f"📦 Equity Holdings — {len(compact)} items | MV: ₹{total_mv:.2f} | P&L: ₹{total_pnl:.2f}"
#             hdrs = [("Symbol", 12), ("Qty", 6), ("Avg", 10), ("LTP", 10), ("P&L", 12)]
#             rows_tbl = [
#                 [c["symbol"], f"{c['qty']:.0f}", f"{c['avg']:.2f}", f"{c['ltp']:.2f}", f"{c['pnl']:.2f}"]
#                 for c in compact
#             ]
#             message = header + "\n" + _table(hdrs, rows_tbl)
#         else:
#             message = "📦 Equity Holdings — None"

#         return {"status": "success", "message": message, "data": compact}

#     # ============================
#     #         POSITIONS
#     # ============================
#     async def _get_positions(self):
#         # Fetch MCP data
#         res = await self.kite_client.call("get_positions", {})
#         print(f"API response for positions: {res}")  # Debug log
#         rows_real = unwrap_list(unwrap_json(res))

#         # Debug log for rows_real
#         print(f"Real data (MCP): {rows_real}")

#         # Merge with dummy data if applicable
#         if self.use_dummy:
#             rows_all = _merge_unique_by_key(rows_real, DUMMY_POSITIONS, "tradingsymbol")
#         else:
#             rows_all = rows_real

#         # Debug log for rows_all
#         print(f"All merged data: {rows_all}")

#         compact = []
#         day_pnl = 0.0

#         for r in rows_all:
#             if not isinstance(r, dict):
#                 continue
#             sym = r.get("tradingsymbol", "")
#             qty = float(r.get("quantity", 0) or 0)
#             pnl = float(r.get("pnl", 0.0) or 0.0)
#             day_pnl += pnl

#             compact.append({"symbol": sym, "qty": qty, "pnl": pnl})

#         if compact:
#             hdrs = [("Symbol", 12), ("Qty", 8), ("P&L", 12)]
#             rows_tbl = [[c["symbol"], f"{c['qty']:.0f}", f"{c['pnl']:.2f}"] for c in compact]
#             message = f"📊 Open Positions — {len(compact)} | Day P&L: ₹{day_pnl:.2f}\n" + _table(hdrs, rows_tbl)
#         else:
#             message = f"📊 Open Positions — None | Day P&L: ₹{day_pnl:.2f}\nNone"

#         return {"status": "success", "message": message, "data": compact}

#     # ============================
#     #       MUTUAL FUNDS
#     # ============================
#     async def _get_mf_holdings(self):
#         # Fetch MCP data
#         res = await self.kite_client.call("get_mf_holdings", {})
#         print(f"API response for MF holdings: {res}")  # Debug log
#         rows = unwrap_list(unwrap_json(res))  # no dummy merge here

#         compact = []
#         invested = value = 0.0

#         for r in rows:
#             if not isinstance(r, dict):
#                 continue
#             scheme = r.get("fund", "")
#             units = float(r.get("quantity", 0.0) or 0.0)
#             avg = float(r.get("average_price", 0.0) or 0.0)
#             nav = float(r.get("last_price", 0.0) or 0.0)

#             cur_val = units * nav
#             inv_val = units * avg

#             invested += inv_val
#             value += cur_val

#             gain_pct = ((cur_val - inv_val) / inv_val * 100.0) if inv_val > 0 else 0.0

#             compact.append({
#                 "scheme": scheme,
#                 "units": units,
#                 "avg_nav": avg,
#                 "nav": nav,
#                 "value": cur_val,
#                 "gain_pct": gain_pct,
#             })

#         if compact:
#             header = (
#                 f"🏦 Mutual Funds — {len(compact)} schemes | Value: ₹{value:.2f} | "
#                 f"Invested: ₹{invested:.2f} | Gain: {((value - invested) / invested * 100 if invested else 0):.2f}%"
#             )
#             lines = ["Scheme                             Units   Avg     NAV     Value"]
#             for c in compact:
#                 nm = c["scheme"][:30] + "…" if len(c["scheme"]) > 31 else c["scheme"]
#                 lines.append(f"{nm:<33} {c['units']:<7.2f} {c['avg_nav']:<8.2f} {c['nav']:<7.2f} {c['value']:.2f}")
#             message = header + "\n" + "\n".join(lines)
#         else:
#             message = "🏦 Mutual Funds — None"

#         return {"status": "success", "message": message, "data": compact}




import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import os
import json
from typing import Any, Dict, Optional, List, Tuple
from dotenv import load_dotenv

load_dotenv(override=True)

from src.kite.portbot.base import Agent
from src.kite.client.kite_mcp_client import KiteMCPClient

# -------------------------
# Dummy Payloads (safe)
# -------------------------
DUMMY_HOLDINGS = [
    {"tradingsymbol": "INFY", "quantity": 2, "average_price": 1450.0, "last_price": 1472.4, "source": "dummy"},
    {"tradingsymbol": "RELIANCE", "quantity": 1, "average_price": 1400.0, "last_price": 1465.2, "source": "dummy"},
    {"tradingsymbol": "HDFCBANK", "quantity": 3, "average_price": 1500.0, "last_price": 1528.5, "source": "dummy"},
]

DUMMY_POSITIONS = [
    {"tradingsymbol": "TCS",  "quantity": 1,  "pnl": 120.50, "source": "dummy"},
    {"tradingsymbol": "SBIN", "quantity": -2, "pnl": -45.75, "source": "dummy"},
]


# -------------------------
# Merge Helpers
# -------------------------
def _merge_unique_by_key(primary: List[Dict[str, Any]], secondary: List[Dict[str, Any]], key: str):
    seen = {x.get(key) for x in primary if isinstance(x, dict)}
    merged = list(primary)
    for x in secondary:
        if not isinstance(x, dict):
            continue
        k = x.get(key)
        if k and k not in seen:
            merged.append(x)
            seen.add(k)
    return merged

def _table(headers, rows):
    """
    Simple table formatting function to create a string representation of tabular data.
    """
    table_str = ""
    # Add headers
    header_row = " | ".join([f"{h[0]:<{h[1]}}" for h in headers])
    table_str += header_row + "\n"
    table_str += "-" * len(header_row) + "\n"

    # Add rows
    for row in rows:
        table_str += " | ".join([str(item).ljust(headers[i][1]) for i, item in enumerate(row)]) + "\n"
    
    return table_str


# ✅ NEW: Direct MCP response parser
def _extract_mcp_data(result: Any) -> List[Dict[str, Any]]:
    """
    Extract list data directly from MCP CallToolResult.
    Handles the specific structure returned by KiteMCPClient.
    """
    # Step 1: Extract text from result.content[0].text
    try:
        if hasattr(result, "content") and isinstance(result.content, list):
            for item in result.content:
                if hasattr(item, "type") and item.type == "text":
                    text = getattr(item, "text", "")
                    if text:
                        # Step 2: Parse JSON string to list
                        data = json.loads(text)
                        if isinstance(data, list):
                            return data
                        elif isinstance(data, dict):
                            # Check for nested list in common keys
                            for key in ("data", "items", "rows"):
                                if key in data and isinstance(data[key], list):
                                    return data[key]
    except Exception as e:
        print(f"Error extracting MCP data: {e}")
    
    return []


# -------------------------
# Portfolio Agent
# -------------------------
class PortfolioAgent(Agent):
    name = "portfolio"
    description = "Manages portfolio data including holdings, positions, and mutual funds"

    tools = [
        {"name": "get_holdings", "description": "Retrieve all stock holdings in the portfolio with quantities and P&L", "parameters": {}},
        {"name": "get_positions", "description": "Get current open positions for the day with entry and exit details", "parameters": {}},
        {"name": "get_mf_holdings", "description": "Fetch mutual fund holdings with current value and returns", "parameters": {}},
    ]

    def __init__(self, kite_client: KiteMCPClient, shared_state: Optional[Dict[str, Any]] = None):
        super().__init__(shared_state)
        self.kite_client = kite_client
        # Ensure we correctly interpret the environment variable
        self.use_dummy = os.getenv("DUMMY_FOR_PORTFOLIO", "0").strip().lower() not in ("0", "false")
        print(f"Use dummy data: {self.use_dummy}")  # Debug log

    async def run(self, tool_name: str, **kwargs: Any) -> Dict[str, Any]:
        print(f"Running tool: {tool_name}")
        if tool_name == "get_holdings":
            return await self._get_holdings()
        elif tool_name == "get_positions":
            return await self._get_positions()
        elif tool_name == "get_mf_holdings":
            return await self._get_mf_holdings()
        raise ValueError(f"Unknown tool: {tool_name}")

    # ============================
    #          HOLDINGS
    # ============================
    async def _get_holdings(self):
        # Fetch MCP data
        res = await self.kite_client.call("get_holdings", {})
        print(f"API response for holdings: {res}")  # Debug log
        
        # ✅ USE NEW EXTRACTOR
        rows_real = _extract_mcp_data(res)
        print(f"Real data (MCP): {rows_real}")

        # ✅ Create a set of symbols from MCP data for quick lookup
        mcp_symbols = {r.get("tradingsymbol") for r in rows_real if isinstance(r, dict)}

        # Merge with dummy data if applicable
        rows_all = _merge_unique_by_key(rows_real, DUMMY_HOLDINGS, "tradingsymbol") if self.use_dummy else rows_real
        print(f"All merged data: {rows_all}")

        compact = []
        total_mv = 0.0
        total_pnl = 0.0

        for r in rows_all:
            if not isinstance(r, dict):
                continue
            sym = r.get("tradingsymbol", "")
            qty = float(r.get("quantity", 0) or 0)
            avg = float(r.get("average_price", 0.0) or 0.0)
            ltp = float(r.get("last_price", 0.0) or 0.0)
            pnl = float(r.get("pnl", (ltp - avg) * qty)) if qty != 0 else float(r.get("pnl", 0.0))

            mv = qty * ltp
            total_mv += mv
            total_pnl += pnl

            # ✅ Determine source by checking if symbol is in MCP data
            source = "mcp" if sym in mcp_symbols else r.get("source", "dummy")

            compact.append({
                "symbol": sym,
                "qty": qty,
                "avg": avg,
                "ltp": ltp,
                "pnl": pnl,
                "source": source,
            })

        if compact:
            header = f"📦 Equity Holdings — {len(compact)} items | MV: ₹{total_mv:.2f} | P&L: ₹{total_pnl:.2f}"
            hdrs = [("Symbol", 12), ("Qty", 6), ("Avg", 10), ("LTP", 10), ("P&L", 12), ("Source", 8)]
            rows_tbl = [
                [c["symbol"], f"{c['qty']:.0f}", f"{c['avg']:.2f}", f"{c['ltp']:.2f}", f"{c['pnl']:.2f}", c["source"]]
                for c in compact
            ]
            message = header + "\n" + _table(hdrs, rows_tbl)
        else:
            message = "📦 Equity Holdings — None"

        return {"status": "success", "message": message, "data": compact}

    # ============================
    #         POSITIONS
    # ============================
    async def _get_positions(self):
        # Fetch MCP data
        res = await self.kite_client.call("get_positions", {})
        print(f"API response for positions: {res}")  # Debug log
        
        # ✅ USE NEW EXTRACTOR
        rows_real = _extract_mcp_data(res)
        print(f"Real data (MCP): {rows_real}")

        # ✅ Create a set of symbols from MCP data for quick lookup
        mcp_symbols = {r.get("tradingsymbol") for r in rows_real if isinstance(r, dict)}

        # Merge with dummy data if applicable
        rows_all = _merge_unique_by_key(rows_real, DUMMY_POSITIONS, "tradingsymbol") if self.use_dummy else rows_real
        print(f"All merged data: {rows_all}")

        compact = []
        day_pnl = 0.0

        for r in rows_all:
            if not isinstance(r, dict):
                continue
            sym = r.get("tradingsymbol", "")
            qty = float(r.get("quantity", 0) or 0)
            pnl = float(r.get("pnl", 0.0) or 0.0)
            day_pnl += pnl

            # ✅ Determine source by checking if symbol is in MCP data
            source = "mcp" if sym in mcp_symbols else r.get("source", "dummy")

            compact.append({"symbol": sym, "qty": qty, "pnl": pnl, "source": source})

        if compact:
            hdrs = [("Symbol", 12), ("Qty", 8), ("P&L", 12), ("Source", 8)]
            rows_tbl = [[c["symbol"], f"{c['qty']:.0f}", f"{c['pnl']:.2f}", c["source"]] for c in compact]
            message = f"📊 Open Positions — {len(compact)} | Day P&L: ₹{day_pnl:.2f}\n" + _table(hdrs, rows_tbl)
        else:
            message = f"📊 Open Positions — None | Day P&L: ₹{day_pnl:.2f}\nNone"

        return {"status": "success", "message": message, "data": compact}

    # ============================
    #       MUTUAL FUNDS
    # ============================
    async def _get_mf_holdings(self):
        # Fetch MCP data
        res = await self.kite_client.call("get_mf_holdings", {})
        print(f"API response for MF holdings: {res}")  # Debug log
        
        # ✅ USE NEW EXTRACTOR
        rows = _extract_mcp_data(res)
        print(f"MF data (MCP): {rows}")

        compact = []
        invested = value = 0.0

        for r in rows:
            if not isinstance(r, dict):
                continue
            scheme = r.get("fund", "")
            units = float(r.get("quantity", 0.0) or 0.0)
            avg = float(r.get("average_price", 0.0) or 0.0)
            nav = float(r.get("last_price", 0.0) or 0.0)

            cur_val = units * nav
            inv_val = units * avg

            invested += inv_val
            value += cur_val

            gain_pct = ((cur_val - inv_val) / inv_val * 100.0) if inv_val > 0 else 0.0

            compact.append({
                "scheme": scheme,
                "units": units,
                "avg_nav": avg,
                "nav": nav,
                "value": cur_val,
                "gain_pct": gain_pct,
                "source": "mcp"
            })

        if compact:
            header = (
                f"🏦 Mutual Funds — {len(compact)} schemes | Value: ₹{value:.2f} | "
                f"Invested: ₹{invested:.2f} | Gain: {((value - invested) / invested * 100 if invested else 0):.2f}%"
            )
            lines = ["Scheme                             Units   Avg     NAV     Value"]
            for c in compact:
                nm = c["scheme"][:30] + "…" if len(c["scheme"]) > 31 else c["scheme"]
                lines.append(f"{nm:<33} {c['units']:<7.2f} {c['avg_nav']:<8.2f} {c['nav']:<7.2f} {c['value']:.2f}")
            message = header + "\n" + "\n".join(lines)
        else:
            message = "🏦 Mutual Funds — None"

        return {"status": "success", "message": message, "data": compact}