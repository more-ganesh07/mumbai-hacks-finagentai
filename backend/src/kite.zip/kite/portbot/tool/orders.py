# src/kite/portbot/tool/orders_agent.py
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import os
from typing import Any, Dict, Optional, List, Tuple
from datetime import datetime
import json

from dotenv import load_dotenv
load_dotenv(override=True)

from src.kite.portbot.base import Agent
from src.kite.client.kite_mcp_client import KiteMCPClient

# NEW: shared JSON unwrappers
from src.kite.portbot.utils.unwrapper import unwrap_json, unwrap_list


# =========================
# Helpers (for formatting)
# =========================

def _fmt_dt_short(s: str) -> str:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return s

def _fmt_num(x) -> str:
    try:
        return f"{float(x):.2f}"
    except Exception:
        return "-"

def _pad(s: str, w: int) -> str:
    s = "" if s is None else str(s)
    return (s if len(s) <= w else s[: w - 1] + " ").ljust(w)

def _table(headers: List[Tuple[str, int]], rows: List[List[str]]) -> str:
    out = [" ".join(_pad(h, w) for h, w in headers)]
    for r in rows:
        out.append(" ".join(_pad(c, headers[i][1]) for i, c in enumerate(r)))
    return "\n".join(out)


# =================
# Dummy Data (safe)
# =================

DUMMY_ORDERS = [
    {
        "order_id": "240101000001234",
        "exchange": "NSE",
        "tradingsymbol": "INFY",
        "transaction_type": "BUY",
        "product": "CNC",
        "quantity": 10,
        "filled_quantity": 10,
        "average_price": 1520.0,
        "status": "COMPLETE",
        "order_timestamp": "2025-01-09T10:21:15+05:30",
    },
    {
        "order_id": "240101000001235",
        "exchange": "NSE",
        "tradingsymbol": "RELIANCE",
        "transaction_type": "SELL",
        "product": "MIS",
        "quantity": 5,
        "filled_quantity": 0,
        "average_price": 0.0,
        "status": "REJECTED",
        "rejection_reason": "Insufficient margin (dummy)",
        "order_timestamp": "2025-01-09T11:03:02+05:30",
    },
]

DUMMY_TRADES = [
    {
        "trade_id": "T24010100004567",
        "order_id": "240101000001234",
        "exchange": "NSE",
        "tradingsymbol": "INFY",
        "quantity": 10,
        "price": 1520.0,
        "trade_timestamp": "2025-01-09T10:21:20+05:30",
        "product": "CNC",
        "transaction_type": "BUY",
    }
]

DUMMY_ORDER_HISTORY = {
    "240101000001234": [
        {"status": "PUT ORDER REQ RECEIVED", "timestamp": "2025-01-09T10:21:10+05:30"},
        {"status": "OPEN", "timestamp": "2025-01-09T10:21:12+05:30"},
        {"status": "COMPLETE", "timestamp": "2025-01-09T10:21:20+05:30"},
    ],
    "240101000001235": [
        {"status": "PUT ORDER REQ RECEIVED", "timestamp": "2025-01-09T11:03:01+05:30"},
        {"status": "REJECTED", "timestamp": "2025-01-09T11:03:02+05:30", "message": "Insufficient margin (dummy)"},
    ],
}


# =================
# Normalizers
# =================

def _norm_orders(items: Any) -> List[Dict[str, Any]]:
    lst = unwrap_list(items)
    out = []
    for x in lst:
        if not isinstance(x, dict):
            continue
        out.append({
            "order_id": x.get("order_id") or x.get("id") or "",
            "symbol": x.get("tradingsymbol") or "",
            "exchange": x.get("exchange") or "",
            "side": x.get("transaction_type") or "",
            "qty": x.get("quantity") or 0,
            "filled_qty": x.get("filled_quantity") or 0,
            "avg_price": x.get("average_price") or 0.0,
            "status": x.get("status") or "",
            "time": x.get("order_timestamp") or x.get("exchange_timestamp") or "",
            "reason": x.get("rejection_reason") or "",
        })
    return out


def _norm_trades(items: Any) -> List[Dict[str, Any]]:
    lst = unwrap_list(items)
    out = []
    for x in lst:
        if not isinstance(x, dict):
            continue
        out.append({
            "trade_id": x.get("trade_id") or "",
            "order_id": x.get("order_id") or "",
            "symbol": x.get("tradingsymbol") or "",
            "exchange": x.get("exchange") or "",
            "qty": x.get("quantity") or 0,
            "price": x.get("price") or 0.0,
            "time": x.get("trade_timestamp") or "",
        })
    return out


def _norm_history(items: Any) -> List[Dict[str, Any]]:
    lst = unwrap_list(items)
    out = []
    for x in lst:
        if not isinstance(x, dict):
            continue
        out.append({
            "time": x.get("timestamp") or x.get("order_timestamp") or "",
            "status": x.get("status") or "",
            "message": x.get("message") or x.get("text") or "",
        })
    return out


# =================
# Merge helpers
# =================

def _merge_unique_by_key(a: List[Dict[str, Any]], b: List[Dict[str, Any]], key: str):
    seen = {x.get(key) for x in a if isinstance(x, dict)}
    merged = list(a)
    for x in b:
        if not isinstance(x, dict):
            continue
        k = x.get(key)
        if k and k not in seen:
            merged.append(x)
            seen.add(k)
    return merged


def _merge_history(a: List[Dict[str, Any]], b: List[Dict[str, Any]]):
    def sig(e: Dict[str, Any]):
        return (
            str(e.get("time") or ""),
            str(e.get("status") or ""),
            str(e.get("message") or "")
        )

    seen = {sig(e) for e in a}
    merged = list(a)
    for e in b:
        s = sig(e)
        if s not in seen:
            merged.append(e)
            seen.add(s)

    try:
        merged.sort(key=lambda e: (e.get("time") or ""))
    except Exception:
        pass

    return merged


# =================
# OrdersAgent
# =================
class OrdersAgent(Agent):
    name = "orders"
    description = "Read-only order/trade queries. Supports dummy merge via DUMMY_FOR_ORDER=1."

    tools = [
        {"name": "get_orders", "description": "List all orders", "parameters": {}},
        {"name": "get_trades", "description": "List trades", "parameters": {}},
        {"name": "get_order_history", "description": "Timeline for one order_id", "parameters": {"order_id": "str"}},
    ]

    def __init__(self, kite_client: KiteMCPClient, shared_state=None):
        super().__init__(shared_state)
        self.kite_client = kite_client

        # Enable dummy via env or shared_state override
        env_flag   = os.getenv("DUMMY_FOR_ORDER", "0").strip().lower() not in ("0", "false")
        state_flag = bool(self.shared_state.get("DUMMY_FOR_ORDER"))
        self.use_dummy = env_flag or state_flag

    async def run(self, tool_name: str, **kwargs):
        if tool_name == "get_orders":
            return await self._get_orders()
        elif tool_name == "get_trades":
            return await self._get_trades()
        elif tool_name == "get_order_history":
            return await self._get_order_history(**kwargs)
        raise ValueError(f"Unknown tool: {tool_name}")

    # ORDERS --------------------------------------------------------
    async def _get_orders(self):
        try:
            raw = await self.kite_client.call("get_orders", {})
            mcp_rows = _norm_orders(unwrap_json(raw))
        except Exception:
            mcp_rows = []

        # Merge real-time orders with dummy data if applicable
        rows = (
            _merge_unique_by_key(mcp_rows, _norm_orders(DUMMY_ORDERS), "order_id")
            if self.use_dummy else mcp_rows
        )

        # Count statuses
        status_counts = {"COMPLETE": 0, "REJECTED": 0, "OPEN": 0, "CANCELLED": 0}
        for r in rows:
            s = (r.get("status") or "").upper()
            if "COMPLE" in s: status_counts["COMPLETE"] += 1
            elif "REJECT" in s: status_counts["REJECTED"] += 1
            elif "CANCEL" in s: status_counts["CANCELLED"] += 1
            elif "OPEN" in s: status_counts["OPEN"] += 1

        headers = [("ID", 14), ("Symbol", 10), ("Side", 5), ("Qty", 5), ("Avg", 8), ("Status", 10), ("Time", 16)]
        rows_tbl = []
        for r in rows[:5]:
            rows_tbl.append([
                (r.get("order_id") or "")[:14],
                (r.get("symbol") or "")[:10],
                (r.get("side") or "")[:5],
                str(r.get("qty") or 0),
                _fmt_num(r.get("avg_price")),
                (r.get("status") or "")[:10],
                _fmt_dt_short(r.get("time") or ""),
            ])

        body = _table(headers, rows_tbl) if rows_tbl else "No orders"
        more = f"\n(+{len(rows) - len(rows_tbl)} more)" if len(rows) > len(rows_tbl) else ""
        msg = (
            f"🧾 Orders — {len(rows)} | "
            f"Complete: {status_counts['COMPLETE']} | Rejected: {status_counts['REJECTED']} | "
            f"Open: {status_counts['OPEN']} | Cancelled: {status_counts['CANCELLED']}\n"
            f"{body}{more}"
        )
        return {"status": "success", "message": msg, "data": rows}

    # TRADES --------------------------------------------------------
    async def _get_trades(self):
        try:
            raw = await self.kite_client.call("get_trades", {})
            mcp_rows = _norm_trades(unwrap_json(raw))
        except Exception:
            mcp_rows = []

        # Merge real-time trades with dummy data if applicable
        rows = (
            _merge_unique_by_key(mcp_rows, _norm_trades(DUMMY_TRADES), "trade_id")
            if self.use_dummy else mcp_rows
        )

        headers = [("TradeID", 16), ("OrderID", 14), ("Symbol", 10), ("Qty", 5), ("Price", 8), ("Time", 16)]
        rows_tbl = []
        for r in rows[:5]:
            rows_tbl.append([
                (r.get("trade_id") or "")[:16],
                (r.get("order_id") or "")[:14],
                (r.get("symbol") or "")[:10],
                str(r.get("qty") or 0),
                _fmt_num(r.get("price")),
                _fmt_dt_short(r.get("time") or ""),
            ])

        body = _table(headers, rows_tbl) if rows_tbl else "No trades"
        more = f"\n(+{len(rows) - len(rows_tbl)} more)" if len(rows) > len(rows_tbl) else ""
        msg = f"🔁 Trades — {len(rows)}\n{body}{more}"
        return {"status": "success", "message": msg, "data": rows}

    # ORDER HISTORY -------------------------------------------------
    async def _get_order_history(self, order_id=None):
        if not order_id and self.use_dummy:
            merged = []
            for oid, hist in DUMMY_ORDER_HISTORY.items():
                merged.append({"order_id": oid, "history": _norm_history(hist)})

            msg_lines = ["📜 Order history (demo)"]
            for x in merged:
                msg_lines.append(x["order_id"])
                for e in x["history"]:
                    line = f"  • {_fmt_dt_short(e['time'])}  {e['status']}"
                    if e.get("message"):
                        line += f" — {e['message']}"
                    msg_lines.append(line)

            return {"status": "success", "message": "\n".join(msg_lines), "data": merged}

        if not order_id:
            return {"status": "error", "message": "order_id required for order history"}

        try:
            raw = await self.kite_client.call("get_order_history", {"order_id": order_id})
            hist_real = _norm_history(unwrap_json(raw))
        except Exception:
            hist_real = []

        if self.use_dummy:
            dummy = _norm_history(DUMMY_ORDER_HISTORY.get(order_id, []))
            hist = _merge_history(hist_real, dummy) if hist_real else dummy
        else:
            hist = hist_real

        if not hist:
            return {"status": "success", "message": f"📜 Order {order_id} history\nNo data", "data": []}

        lines = [f"📜 Order {order_id} history"]
        for e in hist:
            t = _fmt_dt_short(e["time"])
            s = e["status"]
            m = e.get("message")
            lines.append(f"{t}  {s}" + (f" — {m}" if m else ""))

        return {"status": "success", "message": "\n".join(lines), "data": hist}
