import asyncio
import os
from src.kite.client.kite_mcp_client import KiteMCPClient
from src.kite.portbot.tool.portfolio import PortfolioAgent
from src.kite.portbot.tool.login import LoginAgent
from dotenv import load_dotenv

load_dotenv(override=True)

# Set up KiteMCPClient and PortfolioAgent
async def setup_agents():
    # Initialize KiteMCPClient (make sure to set up your environment variables for authentication)
    kite_client = KiteMCPClient()

    # Initialize the LoginAgent and perform login
    login_agent = LoginAgent(kite_client, shared_state={})
    login_result = await login_agent.run(tool_name="login")

    if login_result.get("status") != "success":
        print("❌ Login failed")
        return None

    print("✅ Login successful")

    # Initialize PortfolioAgent with the authenticated Kite client
    portfolio_agent = PortfolioAgent(kite_client)

    return portfolio_agent


# Test PortfolioAgent Tools
async def test_get_holdings(agent):
    print("\n--- Testing get_holdings ---")
    try:
        result = await agent._get_holdings()
        print(f"Response: {result}")
    except Exception as e:
        print(f"Error in get_holdings: {e}")


async def test_get_positions(agent):
    print("\n--- Testing get_positions ---")
    try:
        result = await agent._get_positions()
        print(f"Response: {result}")
    except Exception as e:
        print(f"Error in get_positions: {e}")


async def test_get_mf_holdings(agent):
    print("\n--- Testing get_mf_holdings ---")
    try:
        result = await agent._get_mf_holdings()
        print(f"Response: {result}")
    except Exception as e:
        print(f"Error in get_mf_holdings: {e}")


# Main function to run tests
async def main():
    # Set up agent and login first
    agent = await setup_agents()

    if agent is None:
        print("❌ Unable to initialize PortfolioAgent due to login failure.")
        return

    # Test Portfolio Agent Tools
    await test_get_holdings(agent)
    await test_get_positions(agent)
    await test_get_mf_holdings(agent)


if __name__ == "__main__":
    # Run the tests asynchronously
    asyncio.run(main())
