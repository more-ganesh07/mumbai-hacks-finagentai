# src/kite/portbot/tool/account.py
from typing import Any, Dict

from src.kite.portbot.base import Agent
from src.kite.client.kite_mcp_client import KiteMCPClient
from src.kite.portbot.utils.unwrapper import unwrap_json


class AccountAgent(Agent):
    name = "account"
    description = "Retrieves user profile and account margin information"

    tools = [
        {"name": "get_profile", "description": "Fetch user profile", "parameters": {}},
        {"name": "get_margins", "description": "Get account margins", "parameters": {}},
    ]

    def __init__(self, kite_client: KiteMCPClient, shared_state=None):
        super().__init__(shared_state)
        self.kite_client = kite_client

    async def run(self, tool_name: str, **kwargs: Any) -> Dict[str, Any]:
        if tool_name == "get_profile":
            return await self._get_profile()
        elif tool_name == "get_margins":
            return await self._get_margins()
        raise ValueError(f"Unknown tool: {tool_name}")

    async def _get_profile(self):
        obj = unwrap_json(await self.kite_client.call("get_profile", {}))

        if not isinstance(obj, dict):
            return {"status": "success", "message": str(obj)}

        user = obj
        uid   = user.get("user_id")
        name  = user.get("user_name") or user.get("user_shortname")
        email = user.get("email")
        broker = user.get("broker")
        user_type = user.get("user_type")
        products = ", ".join(user.get("products", []))
        exchanges = ", ".join(user.get("exchanges", []))

        msg = (
            f"👤 Profile: {name} ({uid})  • Broker: {broker}\n"
            f"Type: {user_type}\nEmail: {email}\n"
            f"Products: {products}\nExchanges: {exchanges}"
        )

        return {"status": "success", "message": msg, "data": user}

    async def _get_margins(self):
        obj = unwrap_json(await self.kite_client.call("get_margins", {}))

        if not isinstance(obj, dict):
            return {"status": "success", "message": str(obj)}

        eq = obj.get("equity", {}) or {}
        cm = obj.get("commodity", {}) or {}

        def _mv(d, *keys):
            cur = d
            for k in keys:
                if not isinstance(cur, dict):
                    return 0.0
                cur = cur.get(k, 0.0)
            try:
                return float(cur)
            except:
                return 0.0

        msg = (
            "💰 Margins\n"
            f"• Equity: net ₹{_mv(eq,'net'):.2f}, cash ₹{_mv(eq,'available','cash'):.2f}\n"
            f"• Commodity: net ₹{_mv(cm,'net'):.2f}, cash ₹{_mv(cm,'available','cash'):.2f}"
        )

        return {"status": "success", "message": msg, "data": obj}
