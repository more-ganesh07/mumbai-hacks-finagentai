

######################################################################################

import asyncio
import os
import json
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from groq import AsyncGroq

from src.kite.portbot.agent.master_agent import MasterAgent

load_dotenv(override=True)

def _truncate(s: str, n: int = 8000) -> str:
    return s if len(s) <= n else s[: n - 3] + "..."

class KiteChatbot:
    """
    Chat loop:
      • On enter: MasterAgent connects MCP and runs login() once (you confirm after browser login).
      • After that, user can interact with portfolio/orders/quotes without repeated logins.
    """
    def __init__(self, user_id: Optional[str] = None):
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise ValueError("Missing GROQ_API_KEY in environment")

        self.user_id = user_id or os.getenv("USER_ID", "demo-user")

        self.client = AsyncGroq(api_key=api_key)
        self.model = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
        self.temperature = float(os.getenv("TEMPERATURE", 0.3))
        self.max_tokens = int(os.getenv("MAX_TOKENS", 900))

        self.narrate = os.getenv("NARRATE_USING_LLM", "1").strip().lower() not in ("0", "false")
        self.memory: List[Dict[str, str]] = []
        self.master: Optional[MasterAgent] = None  

    async def __aenter__(self):
        # MasterAgent now handles MCP connect + first login flow internally
        self.master = await MasterAgent(user_id=self.user_id).__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self.master:
            await self.master.__aexit__(exc_type, exc, tb)

    # ------------- LLM streaming -------------
    async def _stream_llm(self, messages: List[Dict[str, str]]) -> str:
        stream = await self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            stream=True,
        )
        full = ""
        async for chunk in stream:
            delta = getattr(chunk.choices[0], "delta", None)
            if delta and getattr(delta, "content", None):
                token = delta.content
                print(token, end="", flush=True)
                full += token
        print()
        return full

    # ------------- Narration prompt -------------
    def _build_narration_messages(self, user_input: str, routed_result: Dict[str, Any]) -> List[Dict[str, str]]:
        sys_prompt = (
            "You are a Zerodha Kite trading assistant.\n"
            "- Never ask for credentials (username, password, PIN, OTP, 2FA, API key).\n"
            "- You already have programmatic access via tools; you are given their results.\n"
            "- Produce clear, structured, human-readable replies in Markdown.\n"
            "- Use INR formatting (₹ and 2 decimals) for amounts when applicable.\n"
            "- If data is empty, say so and suggest a next step.\n"
            "- Be specific and actionable; include brief takeaways and useful follow-ups.\n"
        )

        safe_payload = {
            "composed_message": routed_result.get("message", ""),
            "data": routed_result.get("data", {}),
        }
        tool_context = _truncate(json.dumps(safe_payload, indent=2, ensure_ascii=False), 7000)

        messages: List[Dict[str, str]] = [{"role": "system", "content": sys_prompt}]
        for m in self.memory[-8:]:
            messages.append(m)
        messages.append({"role": "user", "content": user_input})
        messages.append({"role": "assistant", "content": f"[Tool results]\n```json\n{tool_context}\n```"})
        messages.append({"role": "user", "content": "Using the tool results above, answer my question clearly with details and next steps."})
        return messages

    def _remember(self, role: str, content: str):
        self.memory.append({"role": role, "content": content})
        self._maybe_compress_memory()

    def _maybe_compress_memory(self, max_turns: int = 20):
        if len(self.memory) <= max_turns:
            return
        head = self.memory[:6]
        tail = self.memory[6:]
        summary_bits = []
        for m in head:
            tag = m["role"][0].upper()
            txt = m["content"]
            if len(txt) > 160:
                txt = txt[:157] + "..."
            summary_bits.append(f"{tag}:{txt}")
        summary = "Context summary → " + " | ".join(summary_bits)
        self.memory = [{"role": "assistant", "content": summary}] + tail

    # ------------- Chat entry -------------
    async def chat(self, user_input: str):
        # Ignore blank input
        if not user_input.strip():
            return

        # 1) Route query to MasterAgent (tool selection + execution)
        try:
            routed = await self.master.route_query(user_input)
        except Exception as e:
            # Unexpected routing failure → fallback LLM
            print(f"❌ Tool routing failed: {e}\n")
            self._remember("user", user_input)
            self._remember("assistant", str(e))
            return

        # 2) If router/agent layer returned error → show direct error
        if isinstance(routed, Dict) and routed.get("status") == "error":
            err_msg = routed.get("message") or "Something went wrong."
            print(f"❌ {err_msg}\n")
            self._remember("user", user_input)
            self._remember("assistant", err_msg)
            return

        # 3) Successful tool execution → LLM narration or direct output
        if isinstance(routed, Dict) and routed.get("status") == "success":
            if self.narrate:
                # Use LLM to narrate the tool result
                messages = self._build_narration_messages(user_input, routed)
                print("🤖 ", end="", flush=True)
                answer = await self._stream_llm(messages)

                # Store conversation memory
                self._remember("user", user_input)
                self._remember("assistant", answer)

                # Add metadata memory flag
                try:
                    memo = json.dumps({"had_tools": True}, ensure_ascii=False)
                    self._remember("assistant", f"[memo]{memo}")
                except Exception:
                    pass

                return

            else:
                # Direct printing without LLM narration
                pretty = self.master.prefer_message(routed)
                print(f"\n{pretty}\n")

                self._remember("user", user_input)
                self._remember("assistant", pretty)
                return

        # 4) Fallback mode — conversational LLM with no tools
        self._remember("user", user_input)
        system_msg = {
            "role": "system",
            "content": (
                "You are a Zerodha Kite trading assistant. Be concise and helpful.\n"
                "NEVER ask the user for any credentials (username, password, PIN, OTP, 2FA, API key).\n"
                "If tools are unavailable, you may give general advice but DO NOT fabricate account data."
            ),
        }

        messages = [system_msg] + self.memory[-10:]
        print("🤖 ", end="", flush=True)
        answer = await self._stream_llm(messages)

        self._remember("assistant", answer)

async def main():
    async with KiteChatbot() as bot:
        print("💬 Kite Chatbot Ready! (type 'quit' to exit)\n")
        while True:
            try:
                user_input = input("You: ").strip()
                if not user_input:
                    continue
                if user_input.lower() in ["quit", "exit", "bye"]:
                    print("👋 Goodbye!")
                    break
                await bot.chat(user_input)
                print()
            except KeyboardInterrupt:
                print("\n👋 Interrupted")
                break
            except Exception as e:
                print(f"❌ Error: {e}\n")

if __name__ == "__main__":
    asyncio.run(main())
