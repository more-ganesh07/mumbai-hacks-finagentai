
# import asyncio
# import json
# import re
# import os
# import time 
# from typing import Any, Dict, Optional
# from datetime import datetime
# from fastmcp import Client
# from fastmcp.client.transports import SSETransport


# class KiteMCPClient:
#     """
#     Thin wrapper around fastmcp Client specific to Kite MCP tools.

#     ✅ One-time login:
#        - Persists 'mcp-session' cookie to ./session.json
#        - On startup, loads the cookie and attaches it to SSE headers
#        - Validates session with a lightweight 'get_profile' call
#     """

#     SESSION_FILENAME = "session.json"

#     def __init__(self, url: str = "https://mcp.kite.trade/sse", headers: Optional[Dict[str, str]] = None) -> None:
#         self.url = url
#         self.session_path = os.path.join(os.path.dirname(__file__), self.SESSION_FILENAME)

#         self.session_cookie: Optional[str] = None
#         self.is_authenticated: bool = False

#         # 1) Load any existing cookie first
#         self._safe_load_session()

#         # 2) Build headers (include Cookie if present)
#         base_headers = dict(headers or {})
#         if self.session_cookie:
#             base_headers["Cookie"] = f"mcp-session={self.session_cookie}"

#         # 3) Create transport with final headers
#         self.transport = SSETransport(url=self.url, headers=base_headers)
#         self._client: Optional[Client] = None

#     # ---------------- Context manager ----------------

#     async def __aenter__(self) -> "KiteMCPClient":
#         await self.connect()
#         return self

#     async def __aexit__(self, exc_type, exc, tb) -> None:
#         await self.close()

#     async def connect(self) -> None:
#         if self._client is None:
#             self._client = Client(self.transport)
#             await self._client.__aenter__()
#             print("⚡ Connected to Kite MCP SSE.")

#     async def close(self) -> None:
#         if self._client is not None:
#             try:
#                 await self._client.__aexit__(None, None, None)
#             except Exception:
#                 pass
#             self._client = None
#             print("🧹 Kite MCP client closed cleanly.")

#     # ---------------- Session handling ----------------

#     def _safe_load_session(self) -> None:
#         try:
#             if os.path.exists(self.session_path):
#                 with open(self.session_path, "r", encoding="utf-8") as f:
#                     data = json.load(f)
#                     cookie = data.get("cookie")
#                     if cookie:
#                         self.session_cookie = cookie
#                         self.is_authenticated = True
#                         print("🔁 Loaded existing MCP session from file.")
#                     else:
#                         print("ℹ️ session.json present but empty cookie.")
#             else:
#                 print("ℹ️ No session.json found — starting fresh.")
#         except Exception as e:
#             print(f"⚠️ Could not load session.json: {e}")
#             self.session_cookie = None
#             self.is_authenticated = False

#     def save_session(self, cookie_value: str) -> None:
#         if not cookie_value:
#             print("⚠️ Skipped saving empty cookie.")
#             return
#         try:
#             payload = {
#                 "cookie": cookie_value,
#                 "created_at": datetime.utcnow().isoformat() + "Z"
#             }
#             tmp = self.session_path + ".tmp"
#             with open(tmp, "w", encoding="utf-8") as f:
#                 json.dump(payload, f, indent=2)
#             os.replace(tmp, self.session_path)
#             self.session_cookie = cookie_value
#             self.is_authenticated = True
#             print(f"💾 Session saved → {self.session_path}")

#             # Update transport headers for future connects
#             self.transport = SSETransport(
#                 url=self.url,
#                 headers={"Cookie": f"mcp-session={self.session_cookie}"}
#             )
#         except Exception as e:
#             print(f"❌ Failed to save session.json: {e}")

#     async def validate_session(self) -> bool:
#         if not self.is_authenticated or self._client is None:
#             return False
#         print("🔍 Validating stored session...")
#         for attempt in range(1, 3):
#             try:
#                 # A simple authenticated tool to test validity
#                 result = await self.call("get_profile", {})
#                 # If MCP returns a structured response, presence of content is enough
#                 if hasattr(result, "content") and not getattr(result, "is_error", False):
#                     print("✅ Session validated successfully.")
#                     return True
#             except Exception as e:
#                 print(f"⚠️ Validation attempt {attempt} failed: {e}")
#                 await asyncio.sleep(0.8)
#         print("❌ Session invalid — login required.")
#         self.is_authenticated = False
#         return False

#     # ---------------- Tool calls ----------------

#     @property
#     def client(self) -> Client:
#         assert self._client is not None, "Use KiteMCPClient as an async context manager."
#         return self._client

#     async def call(self, tool_name: str, args: Optional[Dict[str, Any]] = None) -> Any:
#         if not self._client:
#             raise RuntimeError("Client not connected. Use `async with KiteMCPClient()`.")

#         # --- TRACE: print the MCP tool call + args (controlled by AGENT_TRACE) ---
#         trace_on = os.getenv("AGENT_TRACE", "1").lower() not in ("0", "false")
#         if trace_on:
#             arg_str = ", ".join(
#                 f"{k}={repr(v)[:80]}..." if len(repr(v)) > 80 else f"{k}={repr(v)}"
#                 for k, v in (args or {}).items()
#             )
#             print(f"🔧 [MCP] call_tool('{tool_name}'{', ' + arg_str if arg_str else ''})")

#         t0 = time.perf_counter()
#         try:
#             result = await self.client.call_tool(tool_name, args or {})
#             if trace_on:
#                 dt = (time.perf_counter() - t0) * 1000.0
#                 print(f"✅ [MCP] {tool_name} — {dt:.0f} ms")
#             return result
#         except Exception as e:
#             if trace_on:
#                 dt = (time.perf_counter() - t0) * 1000.0
#                 print(f"❌ [MCP] {tool_name} — {e} — {dt:.0f} ms")
#             raise RuntimeError(f"Failed to execute {tool_name}: {e}")
#     # ---------------- Parsers ----------------

#     @staticmethod
#     def extract_login_url(login_result: Any) -> Optional[str]:
#         """
#         Extract a login URL from an LLM-like text response.
#         Looks for 'URL: https://...' or any http(s) link containing kite.zerodha.com.
#         """
#         if hasattr(login_result, "content") and isinstance(login_result.content, list):
#             for item in login_result.content:
#                 if getattr(item, "type", None) == "text":
#                     text = getattr(item, "text", "")
#                     if "URL:" in text:
#                         start = text.find("URL: ") + len("URL: ")
#                         return text[start:].strip()
#                     match = re.search(r"https?://[^\s)]+", text)
#                     if match and "kite.zerodha.com" in match.group(0):
#                         return match.group(0)
#         return None

#     @staticmethod
#     def extract_cookie_from_result(login_result: Any) -> Optional[str]:
#         """
#         Try to read a 'mcp-session' or session token straight from the login response.
#         """
#         if hasattr(login_result, "content") and isinstance(login_result.content, list):
#             for item in login_result.content:
#                 if getattr(item, "type", None) == "text":
#                     text = getattr(item, "text", "")
#                     # common patterns
#                     m = re.search(r"(?:mcp-session|session_id)\s*=\s*([A-Za-z0-9._\-]+)", text)
#                     if m:
#                         return m.group(1)
#         return None




# import asyncio
# import json
# import re
# import os
# import time 
# from typing import Any, Dict, Optional
# from datetime import datetime
# from fastmcp import Client
# from fastmcp.client.transports import SSETransport


# class KiteMCPClient:
#     """
#     Thin wrapper around fastmcp Client specific to Kite MCP tools.

#     ✅ One-time login with auto-recovery:
#        - Persists 'mcp-session' cookie to ./session.json
#        - On startup, loads cookie and attaches to SSE headers
#        - Validates session with 'get_profile'
#        - If invalid → automatically re-login using 'login' tool
#     """

#     SESSION_FILENAME = "session.json"

#     def __init__(self, url: str = "https://mcp.kite.trade/sse", headers: Optional[Dict[str, str]] = None) -> None:
#         self.url = url
#         self.session_path = os.path.join(os.path.dirname(__file__), self.SESSION_FILENAME)

#         self.session_cookie: Optional[str] = None
#         self.is_authenticated: bool = False

#         # 1) Load any existing cookie first
#         self._safe_load_session()

#         # 2) Build headers (include Cookie if present)
#         base_headers = dict(headers or {})
#         if self.session_cookie:
#             base_headers["Cookie"] = f"mcp-session={self.session_cookie}"

#         # 3) Create transport with final headers
#         self.transport = SSETransport(url=self.url, headers=base_headers)
#         self._client: Optional[Client] = None

#     # ---------------- Context manager ----------------

#     async def __aenter__(self) -> "KiteMCPClient":
#         await self.connect()
#         return self

#     async def __aexit__(self, exc_type, exc, tb) -> None:
#         await self.close()

#     async def connect(self) -> None:
#         if self._client is None:
#             self._client = Client(self.transport)
#             await self._client.__aenter__()
#             print("⚡ Connected to Kite MCP SSE.")

#     async def close(self) -> None:
#         if self._client is not None:
#             try:
#                 await self._client.__aexit__(None, None, None)
#             except Exception:
#                 pass
#             self._client = None
#             print("🧹 Kite MCP client closed cleanly.")

#     # ---------------- Session handling ----------------

#     def _safe_load_session(self) -> None:
#         """Auto-load session.json if present at startup."""
#         try:
#             if os.path.exists(self.session_path):
#                 with open(self.session_path, "r", encoding="utf-8") as f:
#                     data = json.load(f)
#                     cookie = data.get("cookie")
#                     if cookie:
#                         self.session_cookie = cookie
#                         self.is_authenticated = True
#                         print("🔁 Loaded existing MCP session from file.")
#                     else:
#                         print("ℹ️ session.json present but empty cookie.")
#             else:
#                 print("ℹ️ No session.json found — starting fresh.")
#         except Exception as e:
#             print(f"⚠️ Could not load session.json: {e}")
#             self.session_cookie = None
#             self.is_authenticated = False

#     def load_session(self, file_path: str) -> bool:
#         """Load a cookie from a custom session.json path."""
#         try:
#             if not os.path.exists(file_path):
#                 print(f"❌ No saved session file found at {file_path}")
#                 return False

#             with open(file_path, "r", encoding="utf-8") as f:
#                 data = json.load(f)
#             cookie = data.get("cookie")
#             if not cookie:
#                 print("⚠️ Session file exists but no cookie inside.")
#                 return False

#             self.session_cookie = cookie
#             self.is_authenticated = True
#             print(f"✅ Loaded session cookie from {file_path}")

#             self.transport = SSETransport(
#                 url=self.url,
#                 headers={"Cookie": f"mcp-session={self.session_cookie}"}
#             )
#             return True

#         except Exception as e:
#             print(f"❌ Failed to load session file: {e}")
#             return False

#     def save_session(self, cookie_value: str) -> None:
#         """Save the cookie to local session.json for reuse."""
#         if not cookie_value:
#             print("⚠️ Skipped saving empty cookie.")
#             return
#         try:
#             payload = {
#                 "cookie": cookie_value,
#                 "created_at": datetime.utcnow().isoformat() + "Z"
#             }
#             tmp = self.session_path + ".tmp"
#             with open(tmp, "w", encoding="utf-8") as f:
#                 json.dump(payload, f, indent=2)
#             os.replace(tmp, self.session_path)
#             self.session_cookie = cookie_value
#             self.is_authenticated = True
#             print(f"💾 Session saved → {self.session_path}")

#             self.transport = SSETransport(
#                 url=self.url,
#                 headers={"Cookie": f"mcp-session={self.session_cookie}"}
#             )
#         except Exception as e:
#             print(f"❌ Failed to save session.json: {e}")

#     async def validate_session(self) -> bool:
#         """Validate current session; if invalid, auto-login."""
#         if not self.is_authenticated or self._client is None:
#             print("ℹ️ No active client or unauthenticated.")
#             return await self._auto_relogin()

#         print("🔍 Validating stored session...")
#         for attempt in range(1, 3):
#             try:
#                 result = await self.call("get_profile", {})
#                 if hasattr(result, "content") and not getattr(result, "is_error", False):
#                     print("✅ Session validated successfully.")
#                     return True
#             except Exception as e:
#                 print(f"⚠️ Validation attempt {attempt} failed: {e}")
#                 await asyncio.sleep(0.8)

#         print("❌ Session invalid — attempting auto-login...")
#         return await self._auto_relogin()

#     async def _auto_relogin(self) -> bool:
#         """Auto-login using the 'login' tool."""
#         try:
#             if not self._client:
#                 await self.connect()

#             print("🔐 Triggering login tool automatically...")
#             result = await self.call("login", {})
#             cookie = self.extract_cookie_from_result(result)
#             if not cookie:
#                 print("❌ Could not extract cookie during auto-login.")
#                 return False

#             # Save and rebuild headers
#             self.save_session(cookie)
#             self.transport = SSETransport(
#                 url=self.url,
#                 headers={"Cookie": f"mcp-session={self.session_cookie}"}
#             )
#             print("✅ Auto-login completed successfully.")
#             self.is_authenticated = True
#             return True
#         except Exception as e:
#             print(f"❌ Auto-login failed: {e}")
#             self.is_authenticated = False
#             return False

#     # ---------------- Tool calls ----------------

#     @property
#     def client(self) -> Client:
#         assert self._client is not None, "Use KiteMCPClient as an async context manager."
#         return self._client

#     async def call(self, tool_name: str, args: Optional[Dict[str, Any]] = None) -> Any:
#         if not self._client:
#             raise RuntimeError("Client not connected. Use `async with KiteMCPClient()`.")

#         trace_on = os.getenv("AGENT_TRACE", "1").lower() not in ("0", "false")
#         if trace_on:
#             arg_str = ", ".join(
#                 f"{k}={repr(v)[:80]}..." if len(repr(v)) > 80 else f"{k}={repr(v)}"
#                 for k, v in (args or {}).items()
#             )
#             print(f"🔧 [MCP] call_tool('{tool_name}'{', ' + arg_str if arg_str else ''})")

#         t0 = time.perf_counter()
#         try:
#             result = await self.client.call_tool(tool_name, args or {})
#             if trace_on:
#                 dt = (time.perf_counter() - t0) * 1000.0
#                 print(f"✅ [MCP] {tool_name} — {dt:.0f} ms")
#             return result
#         except Exception as e:
#             if trace_on:
#                 dt = (time.perf_counter() - t0) * 1000.0
#                 print(f"❌ [MCP] {tool_name} — {e} — {dt:.0f} ms")
#             raise RuntimeError(f"Failed to execute {tool_name}: {e}")

#     # ---------------- Parsers ----------------

#     @staticmethod
#     def extract_login_url(login_result: Any) -> Optional[str]:
#         if hasattr(login_result, "content") and isinstance(login_result.content, list):
#             for item in login_result.content:
#                 if getattr(item, "type", None) == "text":
#                     text = getattr(item, "text", "")
#                     if "URL:" in text:
#                         start = text.find("URL: ") + len("URL: ")
#                         return text[start:].strip()
#                     match = re.search(r"https?://[^\s)]+", text)
#                     if match and "kite.zerodha.com" in match.group(0):
#                         return match.group(0)
#         return None

#     @staticmethod
#     def extract_cookie_from_result(login_result: Any) -> Optional[str]:
#         # text items
#         if hasattr(login_result, "content") and isinstance(login_result.content, list):
#             for item in login_result.content:
#                 t = getattr(item, "type", None)
#                 if t == "text":
#                     text = getattr(item, "text", "")
#                     m = re.search(r"(?:mcp-session|session_id)\s*=\s*([A-Za-z0-9._\-]+)", text)
#                     if m:
#                         return m.group(1)
#                 elif t == "json":
#                     try:
#                         blob = getattr(item, "json", None) or json.loads(getattr(item, "text", "{}"))
#                         for key in ("mcp-session", "cookie", "session_id"):
#                             val = blob.get(key)
#                             if isinstance(val, str) and val:
#                                 return val
#                     except Exception:
#                         pass
#         # tool_result style
#         token = getattr(login_result, "result", None) or getattr(login_result, "output", None)
#         if isinstance(token, dict):
#             for key in ("mcp-session", "cookie", "session_id"):
#                 val = token.get(key)
#                 if isinstance(val, str) and val:
#                     return val
#         return None







# ########################################################################################################
