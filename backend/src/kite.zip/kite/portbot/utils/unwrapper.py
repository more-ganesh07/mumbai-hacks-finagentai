# src/kite/portbot/utils/unwrapper.py
import json
from typing import Any, List, Dict
def unwrap_json(result: Any) -> Any:
    """
    Unified MCP JSON parser.
    Handles:
      - result.content[] text chunks
      - JSON in plain text
      - JSON inside code fences ```
      - structured_content / data attributes
      - fallback to raw text
    """
    texts = []
    
    # Check if result contains the 'content' field
    if hasattr(result, "content") and isinstance(result.content, list):
        for item in result.content:
            if hasattr(item, "type") and item.type == "text":
                t = getattr(item, "text", "")
                if t:
                    texts.append(t)

    # Join all text chunks into a single string
    raw = "\n".join(texts).strip()

    # Try parsing the raw JSON if available
    if raw:
        try:
            return json.loads(raw)
        except Exception:
            pass

    # Try parsing fenced blocks (code blocks wrapped with ```) within the raw text
    if "```" in raw:
        for chunk in raw.split("```"):
            s = chunk.strip()
            try:
                return json.loads(s)
            except Exception:
                continue

    # Try checking for structured content or data attributes in the result
    for attr in ("structured_content", "data"):
        if hasattr(result, attr):
            val = getattr(result, attr)
            if val is not None:
                return val

    # Return the raw text if no valid JSON is found
    return raw if raw else None


def unwrap_list(result: Any) -> List[Any]:
    """
    Same as unwrap_json but ensures a LIST output.
    """
    obj = unwrap_json(result)
    
    if isinstance(obj, list):
        return obj

    # In case the returned result is a dict with relevant data keys
    if isinstance(obj, dict):
        for key in ("data", "items", "rows", "bars"):
            if key in obj and isinstance(obj[key], list):
                return obj[key]

    return []  # Return empty list if no data found
