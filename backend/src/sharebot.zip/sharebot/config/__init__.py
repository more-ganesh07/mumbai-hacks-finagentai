# config/__init__.py
from .settings import settings

__all__ = ["settings"]
